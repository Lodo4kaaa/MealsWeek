package org.example.mealsweek.service;

import lombok.RequiredArgsConstructor;
import org.example.mealsweek.dto.DishIngredientDto;
import org.example.mealsweek.dto.mapper.DishIngredientMapper;
import org.example.mealsweek.entity.Dish;
import org.example.mealsweek.entity.DishIngredient;
import org.example.mealsweek.entity.Ingredient;
import org.example.mealsweek.entity.embeddable.DishIngredientKey;
import org.example.mealsweek.exception.ResourceNotFoundException;
import org.example.mealsweek.repository.DishIngredientRepository;
import org.example.mealsweek.repository.DishRepository;
import org.example.mealsweek.repository.IngredientRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
@Transactional
public class DishIngredientService {

    private final DishIngredientRepository dishIngredientRepository;
    private final DishRepository dishRepository;
    private final IngredientRepository ingredientRepository;
    private final DishIngredientMapper dishIngredientMapper;

    @Transactional(readOnly = true)
    public List<DishIngredientDto> getAllByDishId(Long dishId) {
        Dish dish = dishRepository.findById(dishId)
                .orElseThrow(() -> new ResourceNotFoundException("Dish", "id", dishId));

        return dish.getIngredients().stream()
                .sorted(Comparator.comparing(di -> di.getIngredient().getName(), String.CASE_INSENSITIVE_ORDER))
                .map(dishIngredientMapper::toDto)
                .toList();
    }

    public DishIngredientDto create(DishIngredientDto dto) {
        validate(dto);

        Dish dish = dishRepository.findById(dto.dishId())
                .orElseThrow(() -> new ResourceNotFoundException("Dish", "id", dto.dishId()));

        Ingredient ingredient = resolveIngredient(dto);
        DishIngredientKey key = new DishIngredientKey(dish.getId(), ingredient.getId());

        if (dishIngredientRepository.existsById(key)) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Такой ингредиент уже добавлен в это блюдо"
            );
        }

        DishIngredient entity = new DishIngredient();
        entity.setId(key);
        entity.setDish(dish);
        entity.setIngredient(ingredient);
        entity.setAmount(dto.amount());
        entity.setUnit(dto.unit().trim());
        entity.setNote(normalizeText(dto.note()));

        DishIngredient saved = dishIngredientRepository.save(entity);
        return dishIngredientMapper.toDto(saved);
    }

    public DishIngredientDto update(DishIngredientDto dto) {
        validate(dto);

        Dish dish = dishRepository.findById(dto.dishId())
                .orElseThrow(() -> new ResourceNotFoundException("Dish", "id", dto.dishId()));

        Ingredient ingredient = resolveIngredient(dto);
        DishIngredientKey key = new DishIngredientKey(dish.getId(), ingredient.getId());

        DishIngredient entity = dishIngredientRepository.findById(key)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "DishIngredient",
                        "dishId/ingredientId",
                        dto.dishId() + "/" + ingredient.getId()
                ));

        entity.setAmount(dto.amount());
        entity.setUnit(dto.unit().trim());
        entity.setNote(normalizeText(dto.note()));

        DishIngredient saved = dishIngredientRepository.save(entity);
        return dishIngredientMapper.toDto(saved);
    }

    public void delete(Long dishId, Long ingredientId) {
        DishIngredientKey key = new DishIngredientKey(dishId, ingredientId);
        DishIngredient entity = dishIngredientRepository.findById(key)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "DishIngredient",
                        "dishId/ingredientId",
                        dishId + "/" + ingredientId
                ));

        dishIngredientRepository.delete(entity);
    }

    private Ingredient resolveIngredient(DishIngredientDto dto) {
        if (dto.ingredientId() != null) {
            return ingredientRepository.findById(dto.ingredientId())
                    .orElseThrow(() -> new ResourceNotFoundException("Ingredient", "id", dto.ingredientId()));
        }

        String ingredientName = normalizeName(dto.ingredientName());
        if (ingredientName == null || ingredientName.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Нужно передать либо ingredientId, либо ingredientName"
            );
        }

        return ingredientRepository.findByNameIgnoreCase(ingredientName)
                .orElseGet(() -> {
                    Ingredient ingredient = new Ingredient();
                    ingredient.setName(ingredientName);
                    return ingredientRepository.save(ingredient);
                });
    }

    private void validate(DishIngredientDto dto) {
        if (dto.dishId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "dishId обязателен");
        }

        if (dto.amount() == null || dto.amount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Количество должно быть больше 0");
        }

        if (dto.unit() == null || dto.unit().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Единица измерения обязательна");
        }

        boolean hasIngredientId = dto.ingredientId() != null;
        boolean hasIngredientName = dto.ingredientName() != null && !dto.ingredientName().trim().isBlank();

        if (!hasIngredientId && !hasIngredientName) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Нужно передать либо ingredientId, либо ingredientName"
            );
        }
    }

    private String normalizeName(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isBlank() ? null : trimmed;
    }

    private String normalizeText(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isBlank() ? null : trimmed;
    }
}